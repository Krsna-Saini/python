from turtle import Screen,Turtle
import day22PaddleClass
from day22ballclass import ball
import time
from day22scoreboard import Scoreboard
display=Screen()
display.setup(width=800,height=600)
display.title("Pong")
display.bgcolor("black")
display.tracer(0)
newball=ball()
scoreboard=Scoreboard()

r_paddle=day22PaddleClass.Paddle(380,0)
l_paddle=day22PaddleClass.Paddle(-380,0)

display.update()
display.listen()
display.onkey(fun=r_paddle.go_up,key="Up")
display.onkey(fun=r_paddle.go_down,key="Down")
display.onkey(fun=l_paddle.go_up,key="w")
display.onkey(fun=l_paddle.go_down,key="s")
display.onkey(fun=l_paddle.go_down,key="s")
game_is_on=True
speed=0.1

while game_is_on:
    display.update()
    newball.move()
    time.sleep(speed)

    # detect the collision with upper and lower walls
    if newball.ycor()>280 or newball.ycor()<-280:
        newball.bounce_y()
    
    # detecting collision with right paddle and left paddle 
    if (newball.distance(r_paddle)<50 and newball.xcor()>360) or (newball.distance(l_paddle)<50 and newball.xcor()<-360) :
        newball.bounce_x()
        speed/=1.3
    
    # detecting R paddle missing 
    if newball.xcor()>380:
        speed=0.1
        scoreboard.l_point()
        newball.reset_position()
    
    # detecting L paddle missing
    if newball.xcor()<-380:
        speed=0.1
        scoreboard.r_point()
        newball.reset_position()
display.exitonclick()